QA_MYSQL_HOSTNAME=127.0.0.1
QA_MYSQL_USERNAME=qpod_infosys
QA_MYSQL_PASSWORD=PpWiK77pQPJhXS8pSWdItWbwLqMi2rNj5n0M1bTP0VU=
QA_MYSQL_DATABASE=qpod_infosys

QPOD_USERNAME=bitnami
QPOD_PASSWORD=qpod_vmw

QPOD_SOLR_HOSTNAME=localhost
QPOD_SOLR_PORT=8983
QPOD_SOLR_COLLECTION=qpod
QPOD_SOLR_BASE=http://localhost:8983/solr/qpod/

QA_BASE_DIR=/app/qpod/
QA_INCLUDE_DIR=/app/qpod/qa-include/

QPOD_LOG_DIR=/app/qpod/../logs/
QPOD_SCRIPT_DIR=/app/qpod/../scripts/qpod/

# ssh server, client for maintain
