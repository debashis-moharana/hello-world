$(document).ready(function(){ // when the document is loaded completely
	
	$('#shrink-banner').on('click',function(){
		$('.blue-banner').toggleClass('shrink');
	});
});