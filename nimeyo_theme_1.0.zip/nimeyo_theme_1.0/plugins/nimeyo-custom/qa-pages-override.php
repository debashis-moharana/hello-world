<?php
/**
	Nimeyo Theme
	File: qa-pages-override.php
	Description: Overrides the pages from default routing to customized pages
**/
	function qa_page_routing()
	{
		$pages = qa_page_routing_base();
		
		//if (qa_opt('tos_serverside'))
		$pages['tags'] = '../qa-plugin/nimeyo-custom/qa-page-tags.php';
		$pages['tags/recent'] = '../qa-plugin/nimeyo-custom/qa-page-tags-recent.php';
		$pages['tags/hot'] = '../qa-plugin/nimeyo-custom/qa-page-tags-hot.php';
		$pages['tags/name'] = '../qa-plugin/nimeyo-custom/qa-page-tags-name.php';
		$pages['users'] = '../qa-plugin/nimeyo-custom/qa-page-users.php';
		$pages['userdetail/'] = '../qa-plugin/nimeyo-custom/qa-page-user.php';
		$pages['user/'] = '../qa-plugin/nimeyo-custom/qa-page-user.php';
		$pages['users/blocked'] = '../qa-plugin/nimeyo-custom/qa-page-users-inactive.php';
		$pages['users/active'] = '../qa-plugin/nimeyo-custom/qa-page-users.php';
		$pages['dashboard'] = '../qa-plugin/nimeyo-custom/qa-page-dashboard.php';
		$pages['admin/layoutwidgets'] = '../qa-plugin/nimeyo-custom/qa-page-admin-widgets.php';
		$pages['account'] = '../qa-plugin/nimeyo-custom/qa-page-account.php';
	
		// changed to include a new file instead of default page
		return $pages;
	}

