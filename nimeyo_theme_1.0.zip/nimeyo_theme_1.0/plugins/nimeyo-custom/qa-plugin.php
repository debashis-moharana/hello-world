<?php

/*
	Plugin Name: Nimeyo Custom
	Plugin URI:
	Plugin Description: Nimeyo Custom
	Plugin Version: 1.0.1
	Plugin Date: 2011-12-06
	Plugin Author: Nimeyo
	
*/


if (!defined('QA_VERSION')) { // don't allow this page to be requested directly from browser
	header('Location: ../../');
	exit;
}


qa_register_plugin_overrides('qa-pages-override.php');

qa_register_plugin_module('widget', 'qa-activity-count.php', 'qa_nimeyo_activity_count', 'Nimeyo Activity Count');

qa_register_plugin_module('widget', 'qa-category-filter.php', 'qa_nimeyo_category_filter', 'Nimeyo Category Filter');