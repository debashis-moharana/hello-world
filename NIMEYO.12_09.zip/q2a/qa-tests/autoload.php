<?php
// currently, all Q2A code depends on qa-base
require_once __DIR__.'/../qa-include/qa-base.php';
